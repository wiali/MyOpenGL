﻿©2008 Jonathan 'Lonesock' Dummer
See: http://www.gamedev.net/topic/491938-signed-distance-bitmap-font-tool/


This is a modified version of Lonesock's tool:
* automatically finds the best texture size for a font
* automatically appends the font style to the font family name


-Paul