#include "cinder/app/AppBasic.h"
#include "cinder/gl/gl.h"

using namespace ci;
using namespace ci::app;
using namespace std;

class Polyline2TriMeshTestApp : public AppBasic {
public:
	void prepareSettings( Settings *settings );

	void setup();
	void update();
	void draw();

	void mouseDown( MouseEvent event );
	void mouseDrag( MouseEvent event );
	void mouseUp( MouseEvent event );

	void keyDown( KeyEvent event );

	void resize( ResizeEvent event );
public:
	void drawSegment( const Vec2f &p0, const Vec2f &p1, const Vec2f &p2, const Vec2f &p3 );
protected:
	float				mRadius;
	float				mThickness;

	std::vector<Vec2f>	mPoints;

	bool				bIsDragging;
	Vec2i				mDragPos;
	Vec2f				mDragFrom;
	Vec2f				*mDragVecPtr;

	bool				bDrawOutlines;
	bool				bDrawConstruction;

	Vec2i				mWindowSize;
};

void Polyline2TriMeshTestApp::prepareSettings( Settings *settings )
{
	settings->setTitle("Quadstrip from polyline");
	settings->setWindowSize(512, 512);
}

void Polyline2TriMeshTestApp::setup()
{
	mRadius = 5.0f;
	mThickness = 50.0f;

	mPoints.clear();

	bIsDragging = false;

	//
	bDrawOutlines = true;
	bDrawConstruction = true;

	mWindowSize = getWindowSize();
}

void Polyline2TriMeshTestApp::update()
{
}

void Polyline2TriMeshTestApp::draw()
{
	// clear out the window with white
	gl::clear( Color::white() );

	// draw all points as red circles
	gl::color( Color(1, 0, 0) );

	std::vector<Vec2f>::const_iterator itr;
	for(itr=mPoints.begin();itr!=mPoints.end();++itr)
		gl::drawSolidCircle( *itr, mRadius );

	// draw all segments
	for(int i=0;i<mPoints.size();++i) {
		int a = ((i-1) < 0) ? 0 : (i-1);
		int b = i;
		int c = ((i+1) >= mPoints.size()) ? mPoints.size()-1 : (i+1);
		int d = ((i+2) >= mPoints.size()) ? mPoints.size()-1 : (i+2);
		
		drawSegment( mPoints[a], mPoints[b], mPoints[c], mPoints[d] );
	}
}

void Polyline2TriMeshTestApp::mouseDown( MouseEvent event )
{
	// check if any of the points is clicked (distance < radius)
	std::vector<Vec2f>::reverse_iterator itr;
	for(itr=mPoints.rbegin();itr!=mPoints.rend();++itr) {
		float d = Vec2f( event.getPos() ).distance( *itr );
		if(d < mRadius) {
			// start dragging
			mDragPos = event.getPos();
			mDragFrom = *itr;
			mDragVecPtr = &(*itr);
			bIsDragging = true;

			//
			return;
		}
	}

	// not dragging, create new point
	mPoints.push_back( Vec2f( event.getPos() ) );

	// ...and drag it right away
	mDragPos = event.getPos();
	mDragFrom = mPoints.back();
	mDragVecPtr = &(mPoints.back());
	bIsDragging = true;
}

void Polyline2TriMeshTestApp::mouseDrag( MouseEvent event )
{
	if(bIsDragging) 
		*mDragVecPtr = mDragFrom + (event.getPos() - mDragPos);
}

void Polyline2TriMeshTestApp::mouseUp( MouseEvent event )
{
	if(bIsDragging) {
		*mDragVecPtr = mDragFrom + (event.getPos() - mDragPos);
		bIsDragging = false;
	}
}

void Polyline2TriMeshTestApp::keyDown( KeyEvent event )
{
	switch( event.getCode() ) {
	case KeyEvent::KEY_ESCAPE:
		quit();
		break;
	case KeyEvent::KEY_SPACE:
		mPoints.clear();
		break;
	case KeyEvent::KEY_DELETE:
		mPoints.pop_back();
		break;
	case KeyEvent::KEY_o:
		bDrawOutlines = !bDrawOutlines;
		break;
	case KeyEvent::KEY_c:
		bDrawConstruction = !bDrawConstruction;
		break;
	case KeyEvent::KEY_LEFTBRACKET:
		if(mThickness > 1.0f) mThickness -= 1.0f;
		break;
	case KeyEvent::KEY_RIGHTBRACKET:
		if(mThickness < 100.0f) mThickness += 1.0f;
		break;
	}
}

void Polyline2TriMeshTestApp::resize( ResizeEvent event )
{
	// keep points centered
	Vec2f offset = 0.5f * Vec2f( event.getSize() - mWindowSize );

	std::vector<Vec2f>::iterator itr;
	for(itr=mPoints.begin();itr!=mPoints.end();++itr)
		*itr += offset;

	mWindowSize = event.getSize();
}

void Polyline2TriMeshTestApp::drawSegment( const Vec2f &p0, const Vec2f &p1, const Vec2f &p2, const Vec2f &p3 )
{
	// skip if zero length
	if(p1 == p2) return;
	
	// 1) define the line between the two points
	Vec2f line = (p2 - p1).normalized();

	// 2) find the normal vector of this line
	Vec2f normal = Vec2f(-line.y, line.x).normalized();

	// 3) find the tangent vector at both the end points:
	//		-if there are no segments before or after this one, use the line itself
	//		-otherwise, add the two normalized lines and average them by normalizing again
	Vec2f tangent1 = (p0 == p1) ? line : ((p1-p0).normalized() + line).normalized();
	Vec2f tangent2 = (p2 == p3) ? line : ((p3-p2).normalized() + line).normalized();

	// 4) find the miter line, which is the normal of the tangent
	Vec2f miter1 = Vec2f(-tangent1.y, tangent1.x);
	Vec2f miter2 = Vec2f(-tangent2.y, tangent2.x);

	// find length of miter by projecting the miter onto the normal,
	// take the length of the projection, invert it and multiply it by the thickness:
	//		length = thickness * ( 1 / |normal|.|miter| )
	float length1 = mThickness / normal.dot(miter1);
	float length2 = mThickness / normal.dot(miter2);

	// define stipple pattern for later use
	glLineStipple(1, 0xF0F0);

	if(bDrawConstruction) {
		// set line width to 2
		glLineWidth(2.0f);
	
		// draw black line between p1 and p2
		gl::color( Color(0, 0, 0) );
		gl::drawLine( p1, p2 );

		// draw normals in stippled red
		gl::color( Color(1, 0, 0) );
		gl::enable(GL_LINE_STIPPLE);
		gl::drawLine( p1 - normal * mThickness, p1 + normal * mThickness );
		gl::drawLine( p2 - normal * mThickness, p2 + normal * mThickness );	
		gl::disable(GL_LINE_STIPPLE);

		// draw line segment in stippled gray
		gl::color( Color(0.5f, 0.5f, 0.5f) );
		gl::enable(GL_LINE_STIPPLE);
		gl::drawLine( p1 - normal * mThickness, p2 - normal * mThickness );
		gl::drawLine( p1 + normal * mThickness, p2 + normal * mThickness );
		gl::disable(GL_LINE_STIPPLE);
	
		// draw tangents in gray
		gl::color( Color(0.5f, 0.5f, 0.5f) );
		if(p0 != p1) gl::drawLine( p1 - tangent1 * mThickness, p1 + tangent1 * mThickness );
		if(p2 != p3) gl::drawLine( p2 - tangent2 * mThickness, p2 + tangent2 * mThickness );	

		// draw miter (normal of tangents) in stippled black
		gl::color( Color(0, 0, 0) );
		gl::enable(GL_LINE_STIPPLE);
		if(p0 != p1) gl::drawLine( p1 - miter1 * length1, p1 + miter1 * length1 );
		if(p2 != p3) gl::drawLine( p2 - miter2 * length2, p2 + miter2 * length2 );
		gl::disable(GL_LINE_STIPPLE);

		// draw black circles on miter
		gl::color( Color(0, 0, 0) );
		gl::drawSolidCircle( p1 - length1 * miter1, 0.5f * mRadius );
		gl::drawSolidCircle( p1 + length1 * miter1, 0.5f * mRadius );
		gl::drawSolidCircle( p2 - length2 * miter2, 0.5f * mRadius );
		gl::drawSolidCircle( p2 + length2 * miter2, 0.5f * mRadius );
	}

	if(bDrawOutlines) {
		// finally, draw segment in thick black
		glLineWidth(3.0f);
		gl::color( Color::black() );
		gl::drawLine( p1 - length1 * miter1, p2 - length2 * miter2 );
		gl::drawLine( p1 + length1 * miter1, p2 + length2 * miter2 );

		// stipple triangles
		gl::enable(GL_LINE_STIPPLE);
		gl::drawLine( p1 - length1 * miter1, p1 + length1 * miter1 );
		gl::drawLine( p1 - length1 * miter1, p2 + length2 * miter2 );
		gl::drawLine( p2 - length2 * miter2, p2 + length2 * miter2 );
		gl::disable(GL_LINE_STIPPLE);
	}

}

CINDER_APP_BASIC( Polyline2TriMeshTestApp, RendererGl(6) )
